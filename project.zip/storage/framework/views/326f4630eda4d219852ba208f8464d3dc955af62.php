<html>
<head>
  <title>EPUB to PDF Converter</title>
</head>
<body>
    <input type="file" id="epubFileInput">
    <button onclick="convertToPDF()">Convert to PDF</button>
    
  <script>
  
//   pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://unpkg.com/pdfjs-dist@4.1.392/build/pdf.worker.js';

    async function convertToPDF() {
      const epubFileInput = document.getElementById('epubFileInput');
      const epubFile = epubFileInput.files[0];

      // Read the EPUB file as an ArrayBuffer
      const epubArrayBuffer = await epubFile.arrayBuffer();


      // Convert the EPUB to PDF
      const pdfData = await convertEpubToPDF(epubArrayBuffer);


      // Create a PDF file from the converted data
      const pdfFile = new File([pdfData], 'converted.pdf', { type: 'application/pdf' });


      // Trigger a download of the PDF file
      const downloadLink = document.createElement('a');
      downloadLink.href = URL.createObjectURL(pdfFile);
      downloadLink.download = pdfFile.name;
      downloadLink.click();
    }

    async function convertEpubToPDF(epubArrayBuffer) {
     

      // Load the EPUB using the PDF.js library
      const loadingTask = pdfjsLib.getDocument({ data: epubArrayBuffer });
      const pdfDocument = await loadingTask.promise;

      // Convert each page of the EPUB to PDF
      const pdfPromises = [];
      for (let pageNumber = 1; pageNumber <= pdfDocument.numPages; pageNumber++) {
        const page = await pdfDocument.getPage(pageNumber);
        const viewport = page.getViewport({ scale: 1.0 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        await page.render({ canvasContext: context, viewport: viewport }).promise;
        pdfPromises.push(canvas.toDataURL('image/jpeg', 1.0));
      }

      // Combine the PDF pages into a single PDF document
      const pdfDataUrls = await Promise.all(pdfPromises);
      const pdfData = await combinePDFDataUrls(pdfDataUrls);

      return pdfData;
    }

    function combinePDFDataUrls(pdfDataUrls) {
      return new Promise((resolve) => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        const pdfPromises = [];

        canvas.height = 0;
        canvas.width = 0;

        pdfDataUrls.forEach((dataUrl) => {
          const image = new Image();
          image.src = dataUrl;
          pdfPromises.push(
            new Promise((resolveImage) => {
              image.onload = () => {
                canvas.height = image.height > canvas.height ? image.height : canvas.height;
                canvas.width += image.width;
                context.drawImage(image, canvas.width - image.width, 0);
                resolveImage();
              };
            })
          );
        });

        Promise.all(pdfPromises).then(() => {
          const pdfDataUrl = canvas.toDataURL('application/pdf');
          const byteString = atob(pdfDataUrl.split(',')[1]);
          const arrayBuffer = new ArrayBuffer(byteString.length);
          const uint8Array = new Uint8Array(arrayBuffer);

          for (let i = 0; i < byteString.length; i++) {
            uint8Array[i] = byteString.charCodeAt(i);
          }
          resolve(arrayBuffer);
        });
      });
    }
  </script>
</body>
</html><?php /**PATH E:\dev\NikoPdf\pspdfkit-web-example-laravel\resources\views/test88.blade.php ENDPATH**/ ?>