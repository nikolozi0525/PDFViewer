<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Conversion Example</title>
    <script src="https://unpkg.com/convertapi-js/lib/convertapi.js"></script>
</head>
<body>
    <h1>ConvertAPI JavaScript library example</h1>
    <h2>Conversion Example</h2>
    <p>
        <label for="fileInput">Select EPUB file to convert it to PDF</label>
        <input id="fileInput" type="file" accept=".epub, .pdf">
    </p>
    <p id="result">
        Result file:
        <a id="resultLink" href=""></a>
    </p>
    <script>
let convertApi = ConvertApi.auth({secret: '2owMRcQHs0YPknCc'})
let elResult = document.getElementById('result')
let elResultLink = document.getElementById('resultLink')
elResult.style.display = 'none'

// On file input change, start conversion
document.getElementById('fileInput').addEventListener('change', async e => {
    elResult.style.display = 'none'
    document.documentElement.style.cursor = 'wait'
    try {

        // Converting EPUB to PDF file
        let params = convertApi.createParams()
        params.add('file', e.currentTarget.files[0])
        let result = await convertApi.convert('epub', 'pdf', params)

        // Showing link with the result file
        elResultLink.setAttribute('href', result.files[0].Url)
        elResultLink.innerText = result.files[0].Url
        elResult.style.display = 'block'

    } finally {
        document.documentElement.style.cursor = 'default'
    }
})

    </script>
</body>
</html><?php /**PATH E:\dev\NikoPdf\pspdfkit-web-example-laravel\resources\views/test.blade.php ENDPATH**/ ?>