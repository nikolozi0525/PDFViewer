<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pdf/ePub Viewer</title> 	
		<style>
			#pdfviewer-container {
				userSelect: text;
			}

		</style>
		
	</head>
	<body>
		<div id="pdfviewer" style="height: 100vh"></div>
		<script src="assets/pdfviewer/pdfviewer.js"></script>
		<script src="https://unpkg.com/convertapi-js/lib/convertapi.js"></script>
		
		<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
	</body>
</html>
<?php /**PATH E:\dev\NikoPdf\pspdfkit-web-example-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>